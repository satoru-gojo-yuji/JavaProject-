//package com.bookcollection.Bookstore.services;
//
//import com.bookcollection.Bookstore.entities.Users;
//import com.bookcollection.Bookstore.repositories.UserRepo;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.GrantedAuthority;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//
//import java.util.Set;
//import java.util.stream.Collectors;
//
//public class UserDetails implements UserDetailsService {
//    @Autowired
//    private UserRepo userRepo;
//    @Override
//    public User loadUserByUsername(String username)throws UsernameNotFoundException {
//        Users user = userRepo.findById(username).get();
//        if(user==null){
//            throw new UsernameNotFoundException("User not exists by Username");
//        }
//
//        Set<GrantedAuthority> authorities = user.getRole().stream()
//                .map((role) -> new SimpleGrantedAuthority(role.getRole_name()))
//                .collect(Collectors.toSet());
//        return new org.springframework.security.core.userdetails.User(username,user.getPassword(),authorities);
//    }
//}
