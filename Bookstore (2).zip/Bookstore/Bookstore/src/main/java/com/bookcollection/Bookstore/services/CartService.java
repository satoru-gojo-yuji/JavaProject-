package com.bookcollection.Bookstore.services;

import com.bookcollection.Bookstore.Configurations.JwtRequestFilter;
import com.bookcollection.Bookstore.entities.Books;
import com.bookcollection.Bookstore.entities.Cart;
import com.bookcollection.Bookstore.entities.Users;
import com.bookcollection.Bookstore.repositories.BookRepo;
import com.bookcollection.Bookstore.repositories.CartRepo;
import com.bookcollection.Bookstore.repositories.OrderDetailsRepo;
import com.bookcollection.Bookstore.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {
    @Autowired
    private CartRepo cr;
    @Autowired
    private OrderDetailsRepo orderRepo;
    @Autowired
    private BookRepo bookRepo;

    @Autowired
    private UserRepo userRepo;


   public Cart addToCart(Integer bookId){
       Books books= bookRepo.findById(bookId).get();

       String username= JwtRequestFilter.CURRENT_USER;
       Users user=null;
       if (username!=null){
           user=userRepo.findById(username).get();
       }
       if(books!=null && user!=null){
           Cart cart=new Cart(books,user);
          return cr.save(cart);
       }
       return null;



   }

   public void deleteCartItem(Integer cartId){
   cr.deleteById(cartId);
   }
   public List<Cart> getCartDetails(){
       String username= JwtRequestFilter.CURRENT_USER;
       Users user=userRepo.findById(username).get();
       return cr.findByUser(user);

   }
//    public void removeProductFromCart(Cart cart){
//        return cr.delete();
//    }



}
