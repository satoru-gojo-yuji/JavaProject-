package com.bookcollection.Bookstore.services;

import com.bookcollection.Bookstore.Configurations.JwtRequestFilter;
import com.bookcollection.Bookstore.entities.Books;
import com.bookcollection.Bookstore.entities.Cart;
import com.bookcollection.Bookstore.entities.Users;
import com.bookcollection.Bookstore.repositories.BookRepo;
import com.bookcollection.Bookstore.repositories.CartRepo;
import com.bookcollection.Bookstore.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookService {
    @Autowired
    private BookRepo bookRepo;
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private CartRepo cartRepo;
    public void buyBook(Books books){
        bookRepo.save(books);

    }

    public void rentBook(){

    }

    public List<Books> getAllBooks() {
        return bookRepo.findAll();
    }

    public Books getBooksById(Integer bookid) {
        return bookRepo.findById(bookid).get();
    }

    public void delete(String bookid) {
    }

    public void saveOrUpdate(Books books) {
    }

    public List<Books> getBookDetails(boolean isSingleProductCheckout, Integer bookid) {
        if(isSingleProductCheckout && bookid!=0){
            List<Books> list=new ArrayList<>();
            Books books=bookRepo.findById(bookid).get();
            list.add(books);
            return list;
        }
        else{
           String username= JwtRequestFilter.CURRENT_USER;
           Users users = userRepo.findById(username).get();
          List< Cart> carts =cartRepo.findByUser(users);
           return  carts.stream().map(x -> x.getBook()).collect(Collectors.toList());
        }

    }
}
