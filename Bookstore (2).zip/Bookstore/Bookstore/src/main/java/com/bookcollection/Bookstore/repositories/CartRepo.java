package com.bookcollection.Bookstore.repositories;

import com.bookcollection.Bookstore.entities.Cart;
import com.bookcollection.Bookstore.entities.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartRepo extends JpaRepository<Cart,Integer> {
    public List<Cart> findByUser(Users users);
}
