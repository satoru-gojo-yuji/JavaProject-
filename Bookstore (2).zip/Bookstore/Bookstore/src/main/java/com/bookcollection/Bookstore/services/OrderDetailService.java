package com.bookcollection.Bookstore.services;

import com.bookcollection.Bookstore.Configurations.JwtRequestFilter;
import com.bookcollection.Bookstore.entities.*;
import com.bookcollection.Bookstore.repositories.BookRepo;
import com.bookcollection.Bookstore.repositories.CartRepo;
import com.bookcollection.Bookstore.repositories.OrderDetailsRepo;
import com.bookcollection.Bookstore.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderDetailService {
    private static final String ORDER_PLACED="Placed";
    @Autowired
    private OrderDetailsRepo orderDetailsRepo;
    @Autowired
    private BookRepo bookRepo;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private CartRepo cartRepo;
//    @Autowired
//    private UserDetails userDetails;

     public void placeOrder(OrderInput orderInput, boolean isCartCheckout){
        List<OrderProductQuantity>productQuantityList=orderInput.getOrderProductQuantityList();
        for(OrderProductQuantity o:productQuantityList){
            Books books=bookRepo.findById(o.getProductId()).get();
            String currentUser= JwtRequestFilter.CURRENT_USER;
            Users users=userRepo.findById(currentUser).get();
            OrderDetails orderDetails=new OrderDetails(
                    orderInput.getFullName(),
                    orderInput.getFullAddress(),
                    orderInput.getContactNumber(),
                    ORDER_PLACED,
                    books.getPrice()*o.getQuantity(),
                    books,
                    users

                   // orderInput.getOrderProductQuantityList()
            );
            if(isCartCheckout){
               List<Cart> carts =cartRepo.findByUser(users);
               carts.stream().forEach(x ->cartRepo.delete(x));
            }

            orderDetailsRepo.save(orderDetails);

        }
        }
   // }

}
