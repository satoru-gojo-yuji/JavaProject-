package com.bookcollection.Bookstore.services;

import com.bookcollection.Bookstore.entities.Roles;
import com.bookcollection.Bookstore.repositories.RoleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleService {
    @Autowired
    private RoleRepo roleRepo;
    public Roles createNewRole(Roles role){
        return roleRepo.save(role);
    }
}
