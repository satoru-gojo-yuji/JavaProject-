package com.bookcollection.Bookstore.Controllers;

import com.bookcollection.Bookstore.entities.Cart;
import com.bookcollection.Bookstore.services.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CartController {
    @Autowired
    private CartService cartService;
    @PreAuthorize("hasRole('User')")
    @GetMapping("/addToCart/{bookId}")
    public Cart addToCart(@PathVariable(name="bookId") Integer bookId){
      return cartService.addToCart(bookId);

    }

    @PreAuthorize("hasRole('User')")
    @GetMapping("/getCartDetails")
    public List<Cart> getCartDetails(){
     return cartService.getCartDetails();
    }

    @PreAuthorize("hasRole('User')")
    @DeleteMapping("/deleteCartItem")
    public void deleteCartItem(@PathVariable(name="cartItemId") Integer cartId){

    }


}
