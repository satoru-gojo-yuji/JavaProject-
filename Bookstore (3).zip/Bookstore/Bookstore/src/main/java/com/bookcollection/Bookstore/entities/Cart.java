package com.bookcollection.Bookstore.entities;

import jakarta.persistence.*;
import org.springframework.boot.autoconfigure.web.WebProperties;

import java.awt.*;
@Entity
@Table
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer cartId;
    @OneToOne
    private Books book;
     @OneToOne
    private User user;

    public Cart(Books book, User user) {
        this.book = book;
        this.user = user;
    }

    public Integer getCartId() {
        return cartId;
    }

    public Books getBook() {
        return book;
    }

    public void setBook(Books book) {
        this.book = book;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }
}
