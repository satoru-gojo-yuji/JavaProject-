package com.bookcollection.Bookstore.services;

import com.bookcollection.Bookstore.entities.Roles;
import com.bookcollection.Bookstore.entities.User;
import com.bookcollection.Bookstore.repositories.RoleRepo;
import com.bookcollection.Bookstore.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class UserService {
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private RoleRepo roleRepo;
    @Autowired
    private PasswordEncoder passwordEncoder;
    public User registerNewUser(User users){
        return userRepo.save(users);

    }
    public void initRoleAndUser() {

        Roles adminRole = new Roles();
        adminRole.setRole_name("Admin");
        adminRole.setRoleDescription("Admin role");
        roleRepo.save(adminRole);

        Roles userRole = new Roles();
        userRole.setRole_name("User");
        userRole.setRoleDescription("Default role for newly created record");
        roleRepo.save(userRole);
//
        User adminUser = new User();
        adminUser.setEmail("admin@gmail.com");
        adminUser.setPassword(getEncodedPassword("admin@pass"));
        adminUser.setFirstName("admin");
        adminUser.setLastName("admin");
        Set<Roles> adminRoles = new HashSet<>();
        adminRoles.add(adminRole);
        adminUser.setRoles(adminRoles);
        userRepo.save(adminUser);


    }
    public String getEncodedPassword(String password) {
        return passwordEncoder.encode(password);
    }

}
