package com.bookcollection.Bookstore.entities;

import jakarta.persistence.*;

@Entity
public class OrderDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer orderId;
    private String buyerName;
    private String buyersAddress;
    private String buyersContactNumber;
    private String orderStatus;
    private double orderAmonunt;

    @OneToOne
    private Books book;
    @OneToOne
    private User user;

    public OrderDetails(String buyerName, String buyersAddress, String buyersContactNumber, String orderStatus, double v, Books book, User user) {
        this.buyerName = buyerName;
        this.buyersAddress = buyersAddress;
        this.buyersContactNumber = buyersContactNumber;
        this.orderStatus = orderStatus;
        this.orderAmonunt = orderAmonunt;
        this.book = book;
        this.user = user;
    }

    public Books getBook() {
        return book;
    }

    public void setBook(Books book) {
        this.book = book;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Integer getOrderId() {
        return orderId;
    }



    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getBuyersAddress() {
        return buyersAddress;
    }

    public void setBuyersAddress(String buyersAddress) {
        this.buyersAddress = buyersAddress;
    }

    public String getBuyersContactNumber() {
        return buyersContactNumber;
    }

    public void setBuyersContactNumber(String buyersContactNumber) {
        this.buyersContactNumber = buyersContactNumber;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public double getOrderAmonunt() {
        return orderAmonunt;
    }

    public void setOrderAmonunt(double orderAmonunt) {
        this.orderAmonunt = orderAmonunt;
    }
}
