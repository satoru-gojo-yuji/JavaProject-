package com.bookcollection.Bookstore.repositories;

import com.bookcollection.Bookstore.entities.User;
//import com.bookcollection.Bookstore.entities.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
//import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepo extends JpaRepository<User,Long> {

}
