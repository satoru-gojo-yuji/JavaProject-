package com.bookcollection.Bookstore.Controllers;

import com.bookcollection.Bookstore.entities.OrderInput;
import com.bookcollection.Bookstore.services.BookService;
import com.bookcollection.Bookstore.services.OrderDetailService;
import org.aspectj.weaver.ast.Or;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
public class OrderDetailsController {
    @Autowired
    private BookService bookService;
    @Autowired
    private OrderDetailService orderDetailService;
    @PreAuthorize("hasRole('User')")
    @PostMapping("/placeOrder")
    public void placeOrder(@PathVariable(name="isCartCheckout") boolean isCartCheckout, @RequestBody OrderInput orderInput){
    orderDetailService.placeOrder(orderInput,isCartCheckout);
    }
}
