package com.bookcollection.Bookstore.Controllers;

import com.bookcollection.Bookstore.entities.Books;
import com.bookcollection.Bookstore.services.BookService;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

import java.awt.print.Book;

@RestController
public class BooksController {

    @Autowired
    BookService booksService;
    //creating a get mapping that retrieves all the books detail from the database
    @GetMapping("/book")
    private List<Books> getAllBooks()
    {
        return booksService.getAllBooks();
    }
    //creating a get mapping that retrieves the detail of a specific book
    @GetMapping("/book/{bookid}")
    private Books getBooks(@PathVariable("bookid") String bookid)
    {
        return booksService.getBooksById(Integer.valueOf(bookid));
    }
    //creating a delete mapping that deletes a specified book
    @DeleteMapping("/book/{bookid}")
    private void deleteBook(@PathVariable("bookid") String bookid)
    {
        booksService.delete(bookid);
    }
    //creating post mapping that post the book detail in the database
    @PostMapping("/books")
    private int saveBook(@RequestBody Books books)
    {
        booksService.saveOrUpdate(books);
        return books.getBook_id();
    }
    //creating put mapping that updates the book detail
    @PutMapping("/books")
    private Books update(@RequestBody Books books)
    {
        booksService.saveOrUpdate(books);
        return books;
    }

    @GetMapping("/getBookDetails/{isSingleProductCheckout}/{bookid}")
    public List<Books> getBooksDetails(@PathVariable(name="isSingleProductCheckout") boolean isSingleProductCheckout, @PathVariable(name="bookId") Integer bookid)
    {
        return booksService.getBookDetails(isSingleProductCheckout,bookid);
    }


}

